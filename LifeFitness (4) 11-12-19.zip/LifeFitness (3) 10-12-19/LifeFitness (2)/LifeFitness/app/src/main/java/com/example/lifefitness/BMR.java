package com.example.lifefitness;

import java.util.Date;

public class BMR {
    private double bmr_result;
    private String d1;

    public BMR(){}

    public BMR(double bmr_result, String d1) {
        this.bmr_result = bmr_result;
        this.d1 = d1;
    }

    public double getBmr_result() {
        return bmr_result;
    }

    public void setBmr_result(double bmr_result) {
        this.bmr_result = bmr_result;
    }

    public String getD1() {
        return d1;
    }

    public void setD1(String d1) {
        this.d1 = d1;
    }
}
