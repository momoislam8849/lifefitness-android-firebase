package com.example.lifefitness;

public class User {

    public String uname,email;

    public User(){

    }

    public User(String uname, String email) {
        this.uname = uname;
        this.email = email;
    }
}
