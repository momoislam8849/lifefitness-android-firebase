package com.example.lifefitness;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.widget.Toolbar;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import android.os.Bundle;

public class Bm extends AppCompatActivity {
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    EditText ew,eh,eage;
    RadioButton m,f;
    TextView tr;
    Double res;
    String s1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bm);
        eh=findViewById(R.id.height);
        ew=findViewById(R.id.weight);
        eage=findViewById(R.id.age);
        tr=findViewById(R.id.bmrr);
        m=findViewById(R.id.male);
        f= findViewById(R.id.female);
        setUpToolbar();


        navigationView=findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.nav_home:
                        Intent i = new Intent(getApplicationContext(),home.class);
                        startActivity(i);
                        //Toast.makeText(home.this, "Home", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_about:
                        Intent it = new Intent(getApplicationContext(),Bm.class);
                        startActivity(it);
                        Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_info:
                        Intent itt = new Intent(getApplicationContext(),nu_info.class);
                        startActivity(itt);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_his:
                        Intent ita = new Intent(getApplicationContext(),history.class);
                        startActivity(ita);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_pie:
                        Intent itc = new Intent(getApplicationContext(),piechart.class);
                        startActivity(itc);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_ab:
                        Intent itb = new Intent(getApplicationContext(),about.class);
                        startActivity(itb);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_logout:
                        FirebaseAuth.getInstance().signOut();
                        finish();
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                }
                return false;
            }
        });


    }
    private void setUpToolbar(){

        drawerLayout= findViewById(R.id.drawerLayout);
        toolbar = findViewById(R.id.toolbarID);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(Bm.this,drawerLayout,toolbar,R.string.app_name,R.string.app_name);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();



    }
    public void bmrcal1(View view){
        Double vw = new Double(ew.getText().toString());
        Double vh = new Double(eh.getText().toString());
        Double vage = new Double(eage.getText().toString());
        if(f.isChecked())
        {
            double w = (9.6* vw);
            double h = (1.8* vh);
            double a = (4.7 * vage);
            double add = w+h+655;
             res = (1.2*(add - a));
             if (res>=0 && res<=1000){
                 s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                 tr.setText(s1);
             }
             else if (res>1000 && res <=2000){
                 s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                 tr.setText(s1);
             }
             else if (res>2000 && res <=5000){
                 s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                 tr.setText(s1);
             }

        }
        else if(m.isChecked())
        {
            double w = (13.7* vw);
            double h = (5* vh);
            double a = (6.8 * vage);
            double add = w+h+66;
            res = (1.2*(add - a));
            if (res>=0 && res<=1000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>1000 && res <=2000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>2000 && res <=5000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                tr.setText(s1);
            }

        }
    }
    public void bmrcal2(View view){
        Double vw = new Double(ew.getText().toString());
        Double vh = new Double(eh.getText().toString());
        Double vage = new Double(eage.getText().toString());
        if(f.isChecked())
        {
            double w = (9.6* vw);
            double h = (1.8* vh);
            double a = (4.7 * vage);
            double add = w+h+655;
            res = (1.375*(add - a));
            if (res>=0 && res<=1000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>1000 && res <=2000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>2000 && res <=5000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                tr.setText(s1);
            }

        }
        else if(m.isChecked())
        {
            double w = (13.7* vw);
            double h = (5* vh);
            double a = (6.8 * vage);
            double add = w+h+66;
            res = (1.375*(add - a));
            if (res>=0 && res<=1000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>1000 && res <=2000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>2000 && res <=5000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                tr.setText(s1);
            }

        }
    }
    public void bmrcal3(View view){
        Double vw = new Double(ew.getText().toString());
        Double vh = new Double(eh.getText().toString());
        Double vage = new Double(eage.getText().toString());
        if(f.isChecked())
        {
            double w = (9.6* vw);
            double h = (1.8* vh);
            double a = (4.7 * vage);
            double add = w+h+655;
            res = (1.55*(add - a));
            if (res>=0 && res<=1000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>1000 && res <=2000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>2000 && res <=5000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                tr.setText(s1);
            }

        }
        else if(m.isChecked())
        {
            double w = (13.7* vw);
            double h = (5* vh);
            double a = (6.8 * vage);
            double add = w+h+66;
            res = (1.55*(add - a));
            if (res>=0 && res<=1000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>1000 && res <=2000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>2000 && res <=5000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                tr.setText(s1);
            }

        }
    }
    public void bmrcal4(View view){
        Double vw = new Double(ew.getText().toString());
        Double vh = new Double(eh.getText().toString());
        Double vage = new Double(eage.getText().toString());
        if(f.isChecked())
        {
            double w = (9.6* vw);
            double h = (1.8* vh);
            double a = (4.7 * vage);
            double add = w+h+655;
            res = (1.725*(add - a));
            if (res>=0 && res<=1000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>1000 && res <=2000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>2000 && res <=5000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                tr.setText(s1);
            }

        }
        else if(m.isChecked())
        {
            double w = (13.7* vw);
            double h = (5* vh);
            double a = (6.8 * vage);
            double add = w+h+66;
            res = (1.725*(add - a));
            if (res>=0 && res<=1000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>1000 && res <=2000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>2000 && res <=5000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                tr.setText(s1);
            }

        }
    }
    public void bmrcal5(View view){
        Double vw = new Double(ew.getText().toString());
        Double vh = new Double(eh.getText().toString());
        Double vage = new Double(eage.getText().toString());
        if(f.isChecked())
        {
            double w = (9.6* vw);
            double h = (1.8* vh);
            double a = (4.7 * vage);
            double add = w+h+655;
            res = (1.9*(add - a));
            if (res>=0 && res<=1000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>1000 && res <=2000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>2000 && res <=5000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                tr.setText(s1);
            }

        }
        else if(m.isChecked())
        {
            double w = (13.7* vw);
            double h = (5* vh);
            double a = (6.8 * vage);
            double add = w+h+66;
            res = (1.9*(add - a));
            if (res>=0 && res<=1000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 1 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>1000 && res <=2000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 2 would be preferable for you";
                tr.setText(s1);
            }
            else if (res>2000 && res <=5000){
                s1= " "+ res+ " " +"Callori"+"\n"+"Diet 3 would be preferable for you";
                tr.setText(s1);
            }

        }
    }
    public void dt(View view){
        Intent iu = new Intent(getApplicationContext(),dc.class);
        startActivity(iu);
    }

}
