package com.example.lifefitness;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class piechart extends AppCompatActivity {
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    FirebaseAuth mAuth=FirebaseAuth.getInstance();
    PieChart pie;
    PieDataSet dataSet;
    DatabaseReference databaseReference= FirebaseDatabase.getInstance().getReference();
    FirebaseAuth auth=FirebaseAuth.getInstance();
    double jan=0, feb=0, mar=0, ap=0, may=0, jun=0, jul=0, augu=0, sept=0, octo=0, nove=0, decem=0;
    int count=0;
    float arr[];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_piechart);

        setUpToolbar();
        pie = findViewById(R.id.piec);
        pie.setUsePercentValues(true);
        pie.getDescription().setEnabled(false);
        pie.setExtraOffsets(5,10,5,5);
        pie.setDragDecelerationFrictionCoef(0.99f);
        pie.setDrawHoleEnabled(true);
        pie.setHoleColor(Color.WHITE);
        pie.setTransparentCircleRadius(31f);

        setValueIntoChart(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);

        databaseReference.child("cwc").child(auth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot: dataSnapshot.getChildren()){
                    BMR b=snapshot.getValue(BMR.class);
                    float val=(float) b.getBmr_result();
                    if (count==0){
                        jan=Double.valueOf(val);
                    } if (count==1){
                        feb=Double.valueOf(val);
                    } if (count==2){
                        mar=Double.valueOf(val);
                    } if (count==3){
                        ap=Double.valueOf(val);
                    } if (count==4){
                        may=Double.valueOf(val);
                    } if (count==5){
                        jun=Double.valueOf(val);
                    } if (count==6){
                        jul=Double.valueOf(val);
                    } if (count==7){
                        augu=Double.valueOf(val);
                    } if (count==8){
                        sept=Double.valueOf(val);
                    } if (count==9){
                        octo=Double.valueOf(val);
                    } if (count==10){
                        nove=Double.valueOf(val);
                    } if (count==11){
                        decem=Double.valueOf(val);
                    }
                    count=count+1;
                }
                setValueIntoChart(jan, feb, mar, ap, may, jun, jul,augu,sept,octo,nove,decem);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        navigationView=findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.nav_home:
                        Intent i = new Intent(getApplicationContext(),home.class);
                        startActivity(i);
                        //Toast.makeText(home.this, "Home", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_about:
                        Intent it = new Intent(getApplicationContext(),Bm.class);
                        startActivity(it);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_info:
                        Intent itt = new Intent(getApplicationContext(),nu_info.class);
                        startActivity(itt);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_his:
                        Intent ita = new Intent(getApplicationContext(),history.class);
                        startActivity(ita);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_pie:
                        Intent itc = new Intent(getApplicationContext(),piechart.class);
                        startActivity(itc);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_ab:

                        Intent itb = new Intent(getApplicationContext(),about.class);
                        startActivity(itb);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_logout:
                        FirebaseAuth.getInstance().signOut();
                        finish();
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                }
                return false;
            }
        });

    }

    private void setValueIntoChart(double j, double f, double m, double a, double may, double june, double july, double aug, double s, double o, double n, double d) {
        ArrayList<PieEntry> yValues=new ArrayList<>();

        if (j==0 && f==0 && m==0 && a==0 && may==0 && june==0 && july==0 && aug==0 && s==0 && o==0 && n==0 && d==0){
            yValues.add(new PieEntry(0, "No entry"));
        } else {
            if (j>0){
                yValues.add(new PieEntry((float) j, "January"));
            }
            if (f>0){
                yValues.add(new PieEntry((float) f, "February"));
            }
            if (m>0){
                yValues.add(new PieEntry((float) m, "March"));
            }
            if (a>0){
                yValues.add(new PieEntry((float) a, "April"));
            }
            if (may>0){
                yValues.add(new PieEntry((float) may, "May"));
            }
            if (june>0){
                yValues.add(new PieEntry((float) june, "June"));
            }
            if (july>0){
                yValues.add(new PieEntry((float) july, "July"));
            }
            if (aug>0){
                yValues.add(new PieEntry((float) aug, "August"));
            }
            if (s>0){
                yValues.add(new PieEntry((float) s, "September"));
            }
            if (o>0){
                yValues.add(new PieEntry((float) o, "October"));
            }
            if (n>0){
                yValues.add(new PieEntry((float) n, "November"));
            }
            if (d>0){
                yValues.add(new PieEntry((float) d, "December"));
            }
        }

        dataSet=new PieDataSet(yValues, null);
        dataSet.setSliceSpace(0.4f);
        dataSet.setSelectionShift(5f);
        dataSet.setColors(newColor);

        PieData data=new PieData(dataSet);
        data.setDrawValues(false);


        pie.notifyDataSetChanged();
        pie.invalidate();
        pie.setData(data);
    }

    private void setUpToolbar(){

        drawerLayout= findViewById(R.id.drawerLayout);
        toolbar = findViewById(R.id.toolbarID);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(piechart.this,drawerLayout,toolbar,R.string.app_name,R.string.app_name);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();



    }

    public static int[] newColor = {
            Color.rgb(252, 187, 109), Color.rgb(216, 115, 127), Color.rgb(171, 108, 130),
            Color.rgb(104, 93, 121), Color.rgb(71, 92,116)
    };
}
