package com.example.lifefitness;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;

public class d2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d2);
    }
    public void brkf(View view){
        brk2 am = new brk2();
        FragmentManager ff = getSupportFragmentManager();
        FragmentTransaction ft = ff.beginTransaction();
        ft.replace(R.id.fragmentId,am);
        ft.commit();
    }

    public void lun(View view){
        lun2 am = new lun2();
        FragmentManager ff = getSupportFragmentManager();
        FragmentTransaction ft = ff.beginTransaction();
        ft.replace(R.id.fragmentId,am);
        ft.commit();
    }
    public void din(View view){
        din2 am = new din2();
        FragmentManager ff = getSupportFragmentManager();
        FragmentTransaction ft = ff.beginTransaction();
        ft.replace(R.id.fragmentId,am);
        ft.commit();
    }
    public void wat(View view){
        watr2 am = new watr2();
        FragmentManager ff = getSupportFragmentManager();
        FragmentTransaction ft = ff.beginTransaction();
        ft.replace(R.id.fragmentId,am);
        ft.commit();
    }
}
