package com.example.lifefitness;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class dc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dc);
    }
    public void bd1(View view){
        Intent a = new Intent(getApplicationContext(),d1.class);
        startActivity(a);
    }

    public void bd2(View view){
        Intent b = new Intent(getApplicationContext(),d2.class);
        startActivity(b);
    }
    public void bd3(View view){
        Intent c = new Intent(getApplicationContext(),d3.class);
        startActivity(c);
    }
}
