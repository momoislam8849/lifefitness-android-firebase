package com.example.lifefitness;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class home extends AppCompatActivity {
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    EditText ew,eh;
    TextView tr,date;
    FirebaseAuth mAuth=FirebaseAuth.getInstance();
    double res;
    String s,s1, datetime;
    DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference();
    BMR bmm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //String uId=mAuth.getUid();
        ew=findViewById(R.id.weight);
        eh=findViewById(R.id.heightg);
        tr=findViewById(R.id.bmir);
        bmm = new BMR();
        String uId=mAuth.getUid();
        //databaseReference.child("cwc").push().setValue(uId);

        Calendar ca = Calendar.getInstance();
        SimpleDateFormat sp = new SimpleDateFormat("MM-yyyy");
        datetime = sp.format(ca.getTime());
        bmm.setD1(datetime);
        //date.setText(datetime);
        setUpToolbar();

        navigationView=findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.nav_home:
                        Intent i = new Intent(getApplicationContext(),home.class);
                        startActivity(i);
                        Toast.makeText(home.this, "Home", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_about:
                        Intent it = new Intent(getApplicationContext(),Bm.class);
                        startActivity(it);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_info:
                        Intent itt = new Intent(getApplicationContext(),nu_info.class);
                        startActivity(itt);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_his:
                        Intent ita = new Intent(getApplicationContext(),history.class);
                        startActivity(ita);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_pie:
                        Intent itc = new Intent(getApplicationContext(),piechart.class);
                        startActivity(itc);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_ab:
                        Intent itb = new Intent(getApplicationContext(),about.class);
                        startActivity(itb);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_logout:
                        FirebaseAuth.getInstance().signOut();
                        finish();
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                }
                return false;
            }
        });

    }
    private void setUpToolbar(){

        drawerLayout= findViewById(R.id.drawerLayout);
        toolbar = findViewById(R.id.toolbarID);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(home.this,drawerLayout,toolbar,R.string.app_name,R.string.app_name);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();



    }

    public void bmical(View view){
        double vw = Double.valueOf(ew.getText().toString());
        double vh = Double.valueOf(eh.getText().toString());
        res=(vw/(vh*vh));
        bmm.setBmr_result(res);
        databaseReference.child("cwc").child(mAuth.getUid()).child(datetime).setValue(bmm).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    Toast.makeText(home.this,"inserted",Toast.LENGTH_LONG).show();
                }
            }
        });

        if (res < 18.5)
        {

            s="You're in the UNDERWEIGHT range";
        }
        else if(res >=18.5 && res<= 24.9){

            s="You're in the healthy weight range";
        }
        else if(res >=25 && res<= 29.9){
            //tr.setText(new Double(res).toString());
            s="You're in the overweight range";
        }
        else if(res >=30 && res<= 39.9){
            //tr.setText(new Double(res).toString());
            s="You're in the obese range";
        }
        else
        {
            s="YOR IN EXCESSIVE OBESE RANGE";
        }
        s1= " "+ res+ "\n" +s;
        tr.setText(s1);
    }
}
