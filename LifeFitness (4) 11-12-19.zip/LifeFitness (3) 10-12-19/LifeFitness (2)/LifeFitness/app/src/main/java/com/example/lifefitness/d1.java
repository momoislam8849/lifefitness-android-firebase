package com.example.lifefitness;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class d1 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d1);
    }
    public void brkf(View view){
        brk1 am = new brk1();
        FragmentManager ff = getSupportFragmentManager();
        FragmentTransaction ft = ff.beginTransaction();
        ft.replace(R.id.fragmentId,am);
        ft.commit();
    }

    public void lun(View view){
        lun1 am = new lun1();
        FragmentManager ff = getSupportFragmentManager();
        FragmentTransaction ft = ff.beginTransaction();
        ft.replace(R.id.fragmentId,am);
        ft.commit();
    }
    public void din(View view){
        din1 am = new din1();
        FragmentManager ff = getSupportFragmentManager();
        FragmentTransaction ft = ff.beginTransaction();
        ft.replace(R.id.fragmentId,am);
        ft.commit();
    }
    public void wat(View view){
        watr am = new watr();
        FragmentManager ff = getSupportFragmentManager();
        FragmentTransaction ft = ff.beginTransaction();
        ft.replace(R.id.fragmentId,am);
        ft.commit();
    }

}
