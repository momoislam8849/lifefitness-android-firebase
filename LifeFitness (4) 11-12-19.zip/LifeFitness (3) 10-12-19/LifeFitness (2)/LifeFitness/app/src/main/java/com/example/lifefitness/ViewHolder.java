package com.example.lifefitness;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ViewHolder extends RecyclerView.ViewHolder {

    View view;

    public ViewHolder(@NonNull View itemView) {
        super(itemView);
        view=itemView;
    }

    public void setDetails(Context c, double b, String date){
        TextView bmr=view.findViewById(R.id.bmres);
        TextView newDate=view.findViewById(R.id.bmrdate);

        bmr.setText(String.valueOf(b));
        newDate.setText(date);
    }
}
