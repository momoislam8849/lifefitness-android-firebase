package com.example.lifefitness;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class register extends AppCompatActivity {

    EditText emailEditText,pass1,pass2,userName;
    Button SignUp;
    ProgressBar progressBar;
    FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        emailEditText=findViewById(R.id.emailID);
        userName=findViewById(R.id.userID);
        pass1=findViewById(R.id.pass1ID);
        pass2=findViewById(R.id.pass2ID);
        SignUp=findViewById(R.id.signUPID);
        progressBar=findViewById(R.id.progress);
        mAuth=FirebaseAuth.getInstance();
        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String uname = userName.getText().toString();
                final String email = emailEditText.getText().toString();
                String password = pass1.getText().toString();
                String password2 = pass2.getText().toString();
//                Initialize fireBase object

                if(uname.isEmpty()){
                    userName.setError("User name is required");
                    userName.requestFocus();
                    return;

                }
                if(email.isEmpty()){
                    emailEditText.setError("Email is required");
                    emailEditText.requestFocus();
                    return;


                }
                if(password.isEmpty()){
                    pass1.setError("Please enter password");
                    pass1.requestFocus();
                    return;

                }
                if(password2.isEmpty()){
                    pass2.setError("Please confirm password");
                    pass2.requestFocus();
                    return;


                }
                if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    emailEditText.setError("Enter valid email");
                    emailEditText.requestFocus();
                    return;
                }
                if(password.length()<4){
                    pass1.setError("Minimum length should be 4");
                    pass1.requestFocus();
                    return;
                }
                if(!password.equals(password2)){
                    pass2.setError("Passwords Don't match");
                    pass2.requestFocus();
                    return;
                }
                else{
                    progressBar.setVisibility(View.VISIBLE);
                    mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            progressBar.setVisibility(View.GONE);
                            if (task.isSuccessful()) {
                                User user = new User(
                                        uname,
                                        email
                                );
                                FirebaseDatabase.getInstance().getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(register.this, "Successfully Registered", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Toast.makeText(register.this, "Error", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });


                            } else {
                                Toast.makeText(register.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

        }

        });
    }

    protected void onStart() {
        super.onStart();
        if(mAuth.getCurrentUser()!=null){
//            user is already signed in
        }
    }
}