package com.example.lifefitness;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.widget.Toolbar;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class nu_info extends AppCompatActivity {
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    NavigationView navigationView;
    FirebaseAuth mAuth;
    EditText ew,eh,eage;
    RadioButton m,f;
    TextView tr;
    Double res;
    String s1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nu_info);
        setUpToolbar();


        navigationView=findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId())
                {
                    case R.id.nav_home:
                        Intent i = new Intent(getApplicationContext(),home.class);
                        startActivity(i);
                        //Toast.makeText(home.this, "Home", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_about:
                        Intent it = new Intent(getApplicationContext(),Bm.class);
                        startActivity(it);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;

                    case R.id.nav_info:
                        Intent itt = new Intent(getApplicationContext(),nu_info.class);
                        startActivity(itt);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_his:
                        Intent ita = new Intent(getApplicationContext(),history.class);
                        startActivity(ita);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_pie:
                        Intent itc = new Intent(getApplicationContext(),piechart.class);
                        startActivity(itc);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_ab:
                        Intent itb = new Intent(getApplicationContext(),about.class);
                        startActivity(itb);
                        //Toast.makeText(Bm.this, "BMR", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_logout:
                        FirebaseAuth.getInstance().signOut();
                        finish();
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(intent);
                }
                return false;
            }
        });
    }
    private void setUpToolbar(){

        drawerLayout= findViewById(R.id.drawerLayout);
        toolbar = findViewById(R.id.toolbarID);
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(nu_info.this,drawerLayout,toolbar,R.string.app_name,R.string.app_name);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();



    }
}
